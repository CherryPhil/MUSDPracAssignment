package com.example.a1cher.movierater

import android.app.Activity
import android.content.Intent
import android.graphics.Movie
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.review.*
import java.io.Serializable

class ReviewActivity : AppCompatActivity() {
    val DETAILS_ACTIVITY_CODE = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.review)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.review_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if(item?.itemId == R.id.submitReview){
            if (movieReview.text.trim().isEmpty()) {
                movieReview.setError("Field Empty")
            }else{
                val MovieReview = movieReview.text.toString()
                val RatingBar = ratingBar.rating
                val myIntent = Intent()
                myIntent.putExtra("review",MovieReview)
                myIntent.putExtra("ratingBar", RatingBar)
                setResult(Activity.RESULT_OK, myIntent)
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}