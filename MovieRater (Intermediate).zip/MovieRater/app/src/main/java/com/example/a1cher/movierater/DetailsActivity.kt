package com.example.a1cher.movierater

import android.app.Activity
import android.content.Intent
import android.media.Rating
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.details.*
import kotlinx.android.synthetic.main.review.*
import org.intellij.lang.annotations.Language

class DetailsActivity : AppCompatActivity() {
    val REVIEW_ACTIVITY_CODE = 1
    var checkReview = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.details)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        registerForContextMenu(addReview)

        val classMovie = intent.extras.get("MOVIE_CLASS_OBJECT") as MovieClass

        movieTitle.text = classMovie.name
        description.text = classMovie.description
        language.text = classMovie.language
        date.text = classMovie.releaseDate
        suitable.text = classMovie.rating + " " + classMovie.rViolence + " " + classMovie.rLanguage

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 5) {
            if (resultCode == Activity.RESULT_OK) {
                val Review = data!!.getStringExtra("review")
                val RatingBar = data!!.getFloatExtra("ratingBar", 0f)
                review.text = Review
                ratingBar3.visibility = View.VISIBLE
                review.visibility = View.VISIBLE
                addReview.visibility = View.GONE
                ratingBar3.setRating(RatingBar)
            }
        }
            super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        if (v?.id == R.id.addReview) {
            menu?.add(1, 1001, 1, "Add Review")
        }
    }

    override fun onContextItemSelected(item: MenuItem?): Boolean {
        if(item?.itemId == 1001){
            checkReview = true
            var myIntent = Intent(this, ReviewActivity::class.java)
            startActivityForResult(myIntent, 5)
        }
        return super.onContextItemSelected(item)
    }
}