package com.example.a1cher.movierater

import android.content.Intent
import android.graphics.Movie
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.landingpage.*
import java.io.Serializable

class MainActivity : AppCompatActivity() {
    val DETAILS_ACTIVITY_CODE = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        chkBoxRating.setOnClickListener(View.OnClickListener {
            if(chkBoxRating.isChecked == true)
            {
                llRatingChecked.setVisibility(View.VISIBLE)
            }
            else
            {
                llRatingChecked.setVisibility(View.GONE)
                chkBoxViolence.setChecked(false)
                chkBoxLanguage.setChecked(false)
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item?.itemId == R.id.addMovie)
        {
            if (movieName.text.isEmpty() || desc.text.isEmpty() || releaseDate.text.isEmpty()) {
                if (movieName.text.trim().isEmpty())
                    movieName.setError("Field Empty")
                if (desc.text.trim().isEmpty())
                    desc.setError("Field Empty")
                if (releaseDate.text.trim().isEmpty())
                    releaseDate.setError("Field Empty")
            }
            else
            {
                var rGrpId: Int = rgLanguage.checkedRadioButtonId
                val language: RadioButton = findViewById(rGrpId)
                var reason = ""
                if (chkBoxRating.isChecked)
                    if (chkBoxLanguage.isChecked && !chkBoxViolence.isChecked)
                        reason = "Language used"
                    else if (chkBoxViolence.isChecked && !chkBoxLanguage.isChecked)
                        reason = "Violence"
                    else if (!chkBoxViolence.isChecked && !chkBoxLanguage.isChecked)
                        reason = ""
                    else
                        reason = "Violence \n Language Used"

                Toast.makeText(
                    this,
                    "Title = " + movieName.text + "\nOverview = "
                            + desc.text + "\n Release Date = " + releaseDate.text + "\nLanguage = " + language.text + "\nNot Suitable for all ages = " + chkBoxRating.isChecked + "\n Reason:\n" + reason,
                    Toast.LENGTH_SHORT
                ).show()

                var MovieName = movieName.text.toString()
                var Desc = desc.text.toString()
                var Language = language.text.toString()
                var ReleaseDate = releaseDate.text.toString()
                var Rating = ""
                var RatingViolence = ""
                var RatingLanguage = ""
                if (chkBoxRating.isChecked){
                    Rating = "No"
                    if (chkBoxLanguage.isChecked && !chkBoxViolence.isChecked)
                        RatingLanguage = "(Language used)"
                    else if (chkBoxViolence.isChecked && !chkBoxLanguage.isChecked)
                        RatingViolence = "(Violence)"
                    else if (chkBoxViolence.isChecked && chkBoxLanguage.isChecked) {
                        RatingLanguage = "(Language used)"
                        RatingViolence = "(Violence)"
                    }
                }else{
                    Rating = "Yes"
                }

                var classMovie = MovieClass(name = MovieName, description = Desc, language = Language, releaseDate = ReleaseDate, rating = Rating, rViolence = RatingViolence, rLanguage = RatingLanguage)

                var myIntent = Intent(this, DetailsActivity::class.java)
                myIntent.putExtra("MOVIE_CLASS_OBJECT", classMovie as Serializable)
                startActivityForResult(myIntent, DETAILS_ACTIVITY_CODE)

            }
        }else if(item?.itemId == R.id.clear){
            movieName.setText("")
            desc.setText("")
            rbtnEnglish.isChecked
            releaseDate.setText("")
            chkBoxRating.isChecked = false
            llRatingChecked.setVisibility(View.GONE)
            chkBoxViolence.setChecked(false)
            chkBoxLanguage.setChecked(false)
        }
        return super.onOptionsItemSelected(item)
    }
}
