package com.example.a1cher.movierater

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chkBoxRating.setOnClickListener(View.OnClickListener {
            if(chkBoxRating.isChecked == true)
            {
                llRatingChecked.setVisibility(View.VISIBLE)
            }
            else
            {
                llRatingChecked.setVisibility(View.GONE)
                chkBoxViolence.setChecked(false)
                chkBoxLanguage.setChecked(false)
            }
        })
    }
    fun onButtonClick (v: View){
        if (movieName.text.isEmpty() || desc.text.isEmpty() || releaseDate.text.isEmpty()) {
            if (movieName.text.trim().isEmpty())
                movieName.setError("Field Empty")
            if (desc.text.trim().isEmpty())
                desc.setError("Field Empty")
            if (releaseDate.text.trim().isEmpty())
                releaseDate.setError("Field Empty")
        }
        else
        {
            var rGrpId: Int = rgLanguage.checkedRadioButtonId
            val language: RadioButton = findViewById(rGrpId)
            var reason = ""
            if (chkBoxRating.isChecked)
                if (chkBoxLanguage.isChecked && !chkBoxViolence.isChecked)
                    reason = "Language used"
                else if (chkBoxViolence.isChecked && !chkBoxLanguage.isChecked)
                    reason = "Violence"
                else if (!chkBoxViolence.isChecked && !chkBoxLanguage.isChecked)
                    reason = ""
                else
                    reason = "Violence \n Language Used"

            Toast.makeText(
                this,
                "Title = " + movieName.text + "\nOverview = "
                        + desc.text + "\n Release Date = " + releaseDate.text + "\nLanguage = " + language.text + "\nNot Suitable for all ages = " + chkBoxRating.isChecked + "\n Reason:\n" + reason,
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
